Tags: #cybersecurity #careers #red-team #blue-team #SOC #pentesting
Related: [[HOME]] | [[The Adversarial Hook - Understanding Initial Access and Exploitation]]

---

## What is Cybersecurity?

This is the practice of protecting computer systems, networks, and sensitive data from theft, damage, or unauthorized access.

There are 2 sides to this. Red Team and Blue Team.

---

## Red Team

They are the ones who simulate real-world cyber attacks and attempt to breach and exploit an organization's system defenses in order to identify vulnerabilities and cracks within their security.

They ethically hack the system before threat actors can.

**Offensive Security.**

---

## Blue Team

After the red team's penetration testing, they're the ones who improve those security gaps before a problem arises.

They also monitor the system's network traffic to sniff out suspicious activities.

As more on the defense side, they also implement firewalls and other security measures to prevent any unauthorized access.

**Defensive Security.**

---

## Career Opportunities

The cybersecurity field is growing fast — the Bureau of Labor Statistics projects a 33% growth in employment for information security analysts from 2023 to 2033, which is way above the average for most other jobs. Global spending on cybersecurity is also expected to hit $212 billion in 2025, a 15% jump from $183.9 billion the year before, which means there's a lot of investment going into this space.

On the practical side, a lot of these roles offer remote work and flexible schedules, and because the skills are specialized and in high demand, the salaries — even at entry level — tend to be pretty competitive.

A good starting point to explore: https://tryhackme.com/path/outline/introtocyber

---

## Roles

1. **Vulnerability Assessor** — they identify potential weaknesses in applications and systems.
2. **Pentester** — they are the mentioned ethical hackers specialized in network and system security. They actively break into systems and identify vulnerabilities. Compared to threat hunters they're loud/simulated attackers. Red Team.
3. **Security Researcher** — they discover new vulnerabilities through thorough research.
4. **Web Application Pentester** — the ethical hackers but in for web applications and web technologies.
5. **Red Team Operator** — they simulate real tactics threat actors would use to test security defenses.
6. **Security Analyst** — they monitor and respond to security threats.
7. **Threat Hunter** — they are also ethical hackers in network and system security. They proactively search for attackers already hiding within the network. Compared to pentesters, they're the stealthy defenders. Blue Team.
8. **Malware/Reverse Engineering Analyst** — they analyze and break down malicious software and code and have a wide range of programming languages that they use. Python, Powershell, C++ and a deep understanding of Assembly language. They also use both Linux and Windows systems, usually.
9. **Cyber Threat Intelligence Analyst** — they research potential cyber threats, write reports about it and its attackers, and stay informed with the latest trends of threats and attack methods.

---

## Security Operations Center (SOC)

Where a security analyst would be. They monitor and analyze security events in an organization. Identifies and responds to cyber threats, as well as protects the organization from those cyber attacks.

They are crucial for maintaining security posture. Perhaps kind of like a team of security personnel for the company's physical establishment.

### Typical SOC Org Chart

![[Screenshot 2026-05-02 134815.png]]

The SOC operates in three tiers. At the **1st level**, Tier 1 Alert Analysts are the frontliners. They're the first ones to pick up on alerts and flag anything suspicious. When something escalates, it goes to **2nd level**. Tier 2 Incident Responders who dig deeper and handle the actual incident response.

At the **3rd level**, you've got the SOC Manager at the center, surrounded by SME/Hunters in three specializations: Network, Threat Intel, and Malware RE (Reverse Engineering). These are your most experienced people, handling the complex stuff and overseeing the whole operation.

---

## Three Pillars of Cybersecurity

1. **People** — crucial for strong cybersecurity
2. **Processes** — defines the security procedures
3. **Technology** — provides the tools to protect systems

— all of which are essential for effective defense.

---

## What is Penetration Testing?

It's basically a simulated cyber attack on your own system, done intentionally, to find vulnerabilities before actual threat actors do. The goal isn't just to find the vulnerability on paper, but to actually exploit it to confirm it's real and not a false positive.

It also tests how the IT staff responds when they think they're under attack, and checks whether they actually know and follow the organization's security policies and requirements.

--- 

### Penetration Testing Life Cycle

| #   | Phase                    | Nickname                          | What Happens                                                                   |
| --- | ------------------------ | --------------------------------- | ------------------------------------------------------------------------------ |
| 1   | **Recon**                | "Discovering the Target"          | Passive info gathering: Whois, Sublist3r, Google Dorks, Web Tech               |
| 2   | **Enumeration/Scanning** | "Probing the Defenses"            | Active info gathering: Port Scan, VA Scan, Host Discovery                      |
| 3   | **Gaining Access**       | "Breaking In"                     | Exploiting the vulnerability, foothold/initial access                          |
| 4   | **Maintaining Access**   | "Securing Our Foothold"           | Creating backdoors, infecting executables, C2 Connection                       |
| 5   | **Covering Tracks**      | "Erasing Our Footprints"          | Deleting logs, deleting history commands, removing artifacts                   |
| 6   | **Reporting**            | "Documentation and Communication" | Delivering management documentation of findings with suggested countermeasures |

---

## Fundamentals You Actually Need

In an IT field, skipping fundamentals will make things hard and nobody will spoon feed you once you're in. You need to learn the:

- **Operating Systems** — How it works, how it differs from each other
- **Basics of Programming** — Be comfortable with PowerShell/Bash commands and automate your daily tasks. Start with something simple before delving in with more complicated languages.
- **Networking** — The OSI/TCP model, understand how each layer works, common protocols, the three-way handshake, etc.
- **Security Fundamentals** — IS terms like the CIA triad model, different attacks, threats, vulnerabilities, and risks.
- **Security Standards** — Such as the NIST standard specification, RMF, Cybersecurity Framework, and CIS.
- **Frameworks/Methodology** — If you're leaning towards cybersecurity, the next step is to get familiarized with PTES, MITRE ATT&CK, Cyber Kill Chain, and OWASP Top 10.
- **Most importantly, get your hands dirty** — Practice in solving CTF challenges.
