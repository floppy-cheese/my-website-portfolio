Tags: #cybersecurity #initial-access #valid-accounts #MITRE #defense-in-depth #credentials
Related: [[HOME]] | [[Initial Access (TA0001) — Phishing (T1566)]] | [[Initial Access (TA0001) — Exploit Public-Facing Application (T1190)]]

---

## The Core Idea

Adversaries abuse existing account credentials for Initial Access, Persistence, Privilege Escalation, or Defense Evasion. The scary part is that compromised credentials don't break through access controls, they just walk right past them like a legitimate user. That means persistent access to systems and external services like VPNs, OWA, network devices, and remote desktop becomes trivially easy.

---

## The Perimeter Bypass

When adversaries have valid login details, traditional perimeter defenses aren't defeated, they're made completely irrelevant.

A firewall can't stop someone who already has the keys. That's what makes this technique so dangerous and so commonly abused. The attacker looks exactly like a normal user to most detection systems.

---

## The Initial Access Spectrum (MITRE TA0001)

Three broad categories of vectors attackers use to get those valid credentials in the first place:

- **Human-targeted Vectors** — phishing, social engineering, tricking employees into giving up creds
- **Infrastructure-targeted Vectors** — exploiting exposed services, VPNs, or misconfigured systems
- **Identity-targeted Vectors** — directly going after accounts through credential stuffing, brute force, or credential databases

---

## The Attack Vector Funnel

![[Screenshot 2026-05-02 163113.png]]

This diagram maps the full journey from stolen credential to full network compromise across four stages:

- **Stage 1 — Source (Exposure):** Where the credentials come from. Data breaches, phishing scams, third-party vendor exposure, or just predictable passwords.
- **Stage 2 — Method (Weaponization):** Automated Credential Stuffing. Attackers use bots to fire stolen username-password pairs across thousands of corporate endpoints until something sticks.
- **Stage 3 — Entry (Initial Access, TA0001):** The valid account successfully authenticates. At this point, the attacker is in and from the system's perspective, nothing looks wrong.
- **Stage 4 — Impact (Exploitation):** Account Takeover (ATO) leads directly to Lateral Movement and Privilege Escalation across the internal network. Game over if undetected.

---

## The Valid Accounts Matrix (T1078 Breakdown)

MITRE breaks T1078 into four specific classifications depending on what type of account gets abused:

| Classification | Account Type     | What It Means                                                                        |
| -------------- | ---------------- | ------------------------------------------------------------------------------------ |
| **T1078.001**  | Default Accounts | Factory-default credentials that were never changed (think `admin/admin`)            |
| **T1078.002**  | Domain Accounts  | Standard Active Directory accounts used across an organization                       |
| **T1078.003**  | Local Accounts   | Device-level accounts, usually with less visibility than domain accounts             |
| **T1078.004**  | Cloud Accounts   | Cloud service accounts (AWS, Azure, GCP) increasingly targeted as orgs move to cloud |

---

## Rogue's Gallery: Known T1078 Abusers

These are real-world threat groups known for heavily using valid account abuse:

- **LAPSUS$** — notorious for social engineering and SIM swapping to steal credentials
- **Sandworm Team** — Russian state-sponsored group, although they do use compromised accounts, their reputation is more about destruction and disruption
- **APT28 (Fancy Bear)** — Russian GRU group, credential theft is a core part of their playbook
- **Volt Typhoon** — Chinese state-sponsored, focuses on "living off the land" using valid credentials to blend in and avoid detection

---

## Defense in Depth

![[Screenshot 2026-05-02 163611.png]]

Defense in Depth is a strategy that stacks multiple layers of security so that if one fails, others are still in place. Think of it like an onion. Each ring is a different layer of protection, and an attacker has to peel through all of them.

From outermost to innermost:

- **Human element** → Awareness and training
- **Physical layer** → Data diode
- **Network layer** → IDS, IPS, firewall
- **Application layer** → Application monitoring
- **Data integrity** → File integrity monitoring
- **Data** → Data diode
- **Data access** → Permissions control
- **User management** → IAM, LDAP, Active Directory
- **Network access** → NAC, ACL
- **Physical access** → Biometrics, physical access systems

No single layer is sufficient on its own. 

---

## Architecting Defense-in-Depth Against T1078

![[Screenshot 2026-05-02 163754.png]]

Mitigating credential abuse needs a layered architecture that assumes breach and actively hunts for exposure. Three layers:

**Top Layer — Threat Intelligence & Validation**
Real-time threat intel gathering from multiple dark web sources. This layer actively validates whether credentials have been leaked and checks them against Active Directory and external services before they can be used.

**Middle Layer — Access Control & Policies**
Multi-Factor Authentication (MFA) across all accounts. Default, local, domain, and cloud. On top of that, conditional access policies and eliminating legacy authentication methods that don't support modern controls.

**Base Layer — Zero Trust & PAM**
The foundation. Privileged Account Management (PAM) handles the heavy lifting here with continuous verification routinely auditing accounts, removing inactive users, and enforcing least-privilege so compromised accounts can't do much damage even if accessed.

---

## Password Storage: The Two-Tiered Defense Blueprint

A practical approach to actually securing credentials:

- **Tier 1: Enterprise Architecture (The Shield)** — organization-wide systems that manage and enforce password policies, centralize credential storage, and integrate with IAM solutions
- **Tier 2: Individual Vaults (The Lock)** — personal password managers at the user level, available as either cloud-based sync (accessible across devices) or local storage (stays offline, higher control)

Both tiers matter. Enterprise controls mean nothing if employees are reusing `Password123` and storing it in a notes app.
