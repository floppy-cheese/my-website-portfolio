Tags: #cybersecurity #execution #powershell #scripting #MITRE #fileless-malware
Related: [[HOME]] | [[Initial Access (TA0001) — Exploit Public-Facing Application (T1190)]] | [[Persistence (TA0003)]]

---

## What is Execution (TA0002)?

The adversary is trying to run malicious code. Simple as that.

Execution is the tactic covering all techniques that result in attacker-controlled code running on a local or remote system. It rarely stands alone. Execution techniques are almost always paired with techniques from other tactics to achieve bigger goals, like moving through the network or stealing data.

---

## Command and Scripting Interpreter (T1059)

Instead of dropping custom malware that antivirus will immediately flag, attackers use the OS's own built-in administrative tools against it. That's the whole idea here. Abuse what's already installed and trusted.

Adversaries weaponize command-line interfaces and scripting languages to execute commands, scripts, or binaries. The OS can't really tell the difference between a sysadmin running a script and an attacker doing the same thing which is exactly what makes this technique so effective.

---

## T1059.001 — PowerShell

The most heavily abused scripting language in Windows environments. It's powerful, it's built-in, and it can do basically anything on the system.

Common attacker uses:
- Downloading payloads from remote servers
- Executing base64-encoded commands to avoid detection
- Reflectively loading malware directly into memory — fileless malware, meaning nothing ever touches the disk and disk scanners can't catch it

---
## Gootloader Infection Chain

![[Screenshot 2026-05-02 171810.png]]

Gootloader is a real-world example of how JavaScript and PowerShell get chained together in a multi-stage attack:

1. **SEO Poisoning** — the victim finds the malicious site through manipulated search results
2. **Download** — victim downloads an archived file containing a JavaScript file from a compromised website
3. **First Stage Execution** — victim runs the first-stage GootLoader JavaScript file
4. **Persistence** — GootLoader creates persistence via a Scheduled Task so it survives reboots
5. **Second Stage** — drops and executes a second-stage JavaScript GootLoader
6. **Final Payload** — executes the third stage and main GootLoader payload via PowerShell

The file properties shown in the diagram give it away in hindsight — a 3.6MB JavaScript file disguised as a letter about a contract renewal. The execution chain goes: `wscript.exe` → `cscript.exe` → `powershell.exe` → `conhost.exe`. Classic living-off-the-land abuse.

---

## T1059.007 — JavaScript / JScript / VBScript

Often embedded inside malicious Office files, PDFs, or HTML pages — executes the moment the user interacts with it.

**GootLoader** is the key example here too. It's a sophisticated JavaScript malware loader used by threat actors for initial access and delivering post-exploitation payloads like ransomware. What makes it tricky is that JavaScript is so common and expected in web environments that it blends right in.

---

## T1059.003 — Windows Command Shell

Batch files (`.bat` or `.cmd`) give the shell a list of sequential commands to execute — conditionals, loops, the works. Attackers love these for:

- Long or repetitive tasks that need to run automatically
- Running the same set of commands across multiple systems at once

It's not as flashy as PowerShell but it gets the job done and is available on every Windows machine ever made.

---

## Defending Against Script Abuse

Blue Team actions to counter T1059:

- **Script Block Logging** — enable Windows Event ID 4104 to record the full, deobfuscated content of PowerShell scripts as they run. Even if the script was encoded, the log captures what it actually did.
- **Execution Policies (Constrained Language Mode)** — restrict PowerShell's capabilities for non-admin users so they can't just run whatever they want.
- **Command-Line Monitoring** — use EDR or Sysmon to flag suspicious arguments like `-enc` (base64 encoded), `-w hidden` (hidden window), or `iex` (Invoke-Expression). These are classic attacker tells.
- **Application Control (AppLocker)** — restrict execution of unnecessary interpreters like `wscript.exe` that most users have no business running.
