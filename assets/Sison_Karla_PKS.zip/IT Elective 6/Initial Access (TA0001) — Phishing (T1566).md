Tags: #cybersecurity #initial-access #phishing #MITRE #email-security
Related: [[HOME]] | [[IT Elective 6/Introduction to Security Models and Threat Frameworks|Introduction to Security Models and Threat Frameworks]] | [[Initial Access (TA0001) — Valid Accounts (T1078)]]

---

## Phishing

The Tactic — "Why". The attacker's goal is to gain an initial foothold in the target's network.

Attackers usually don't brute-force their way through firewalls, that's too loud and too hard. Instead, they take the path of least resistance. Tricking a human into opening the door for them.

Phishing is a classic violation of Confidentiality in the CIA Triad. The whole point is to get users to hand over their login credentials without realizing it.

---

## Types of Malicious Emails

Not all phishing is the same. Here's the breakdown from least to most targeted:

| Type               | What It Is                                                                 |
| ------------------ | -------------------------------------------------------------------------- |
| **Spam**           | Unsolicited junk sent in bulk. The stuff clogging your promotions tab      |
| **Phishing**       | Tries to steal sensitive info by impersonating a trusted entity            |
| **Spear Phishing** | Same idea, but targeted at a specific individual or organization           |
| **Whaling**        | Spear phishing but aimed at C-level executives. Bigger fish, bigger payoff |
| **Smishing**       | Phishing via SMS/text messages                                             |
| **Vishing**        | Voice call-based social engineering                                        |

The more targeted it gets, the more effort went into it, and the harder it is to spot.

---

## Phishing Email Characteristics

If you know what to look for, most phishing emails give themselves away:

- **Spoofed sender address** — looks like it's from a trusted source, but the actual domain is off
- **Urgency in the subject/body** — keywords like "Invoice," "Suspended," "Action Required", anything that makes you panic and click without thinking
- **Hidden hyperlinks** — URLs masked using shortening services so you can't see where they actually go
- **Malicious attachments** — disguised as legitimate documents (PDFs, Word files, etc.)

---

## How Email Actually Works

Understanding this helps when you're analyzing whether an email is legit or not.

1. **Compose** — you write the email in your client
2. **SMTP Server** — your "post office," sends the email out
3. **DNS Server** — looks up the address to find the destination mail server
4. **MX Server** — the recipient's "local post office," receives the incoming mail
5. **User Inbox** — the email finally lands in the recipient's mailbox

Each one of those hops leaves a trace in the email headers which is exactly what analysts look at.

---

## Phishing Analysis: Techniques & Tools

### Analyzing Email Headers

Headers contain the full travel log of an email. Where it came from, what servers it passed through, and whether it actually is who it says it is.

The three main authentication checks to look for:

- **SPF (Sender Policy Framework)** — checks if the sender's IP is on the domain's authorized list of sending IPs. Basically, *"is this server allowed to send email on behalf of this domain?"*
- **DKIM (DomainKeys Identified Mail)** — uses a cryptographic signature to verify the email hasn't been tampered with in transit
- **DMARC (Domain-based Message Authentication, Reporting, and Conformance)** — the policy layer on top of SPF and DKIM. Tells the receiving server what to do if those checks fail (reject, quarantine, or just report it)

If any of these fail or are missing, that's a red flag.

---

### Header Analysis Tools

| Tool | What It Does |
|------|-------------|
| **MXToolbox** | Detects phishing, spam, malware, impersonation scams |
| **Google MessageHeader** | Breaks down headers and helps identify responsible parties |
| **MailHeader** | Analyzes headers for security threats |
| **Azure Header Analyzer** | Retrieves and displays transport headers in a readable format |
| **Gaijin** | Breaks down Received lines individually with clean display |
| **Trace Email** | Analyzes headers and traces sender IP location + WHOIS |

#### Message Header Analyzer (the go-to)

Available as a web tool or Outlook add-in. It's the most useful for a quick first look because it:

- Converts the raw confusing header text into something human-readable
- Instantly shows SPF, DKIM, and DMARC results (Pass/Fail)
- Visualizes each server hop the email passed through. Useful for spotting suspicious routing or unexpected delays

If you're doing a quick legitimacy check on a suspicious email, start here.

---

### URL & IP Analysis Tools

Once you've flagged a suspicious link, you don't click it — you analyze it.

| Tool | What It Does |
|------|-------------|
| **VirusTotal** | Scans files, domains, IPs, and URLs for malware across multiple engines |
| **Talosintelligence** | Identifies malicious domains and IPs |
| **AbuseIPDB** | Checks IP reputation |
| **CriminalIP** | Real-time URL scanner and phishing link checker |
| **MXToolBox Blacklist** | Checks a mail server IP against 100+ DNS-based blacklists |
| **IP Blacklist Checker** | Checks if a domain/IP/email is on DNSBL or other blacklists |
| **URLVOID** | Checks URL/domain reputation for phishing or malicious content |

---

### REMnux Platform

REMnux is a Linux toolkit built specifically for malware analysis and reverse engineering. It comes pre-loaded with tools for analyzing malicious artifacts including emails.

Relevant email analysis tools within REMnux:

- **emldump** — parses and analyzes `.eml` files
- **msg-extractor** — extracts emails and attachments from `.msg` files
- **msgconvert** — converts `.msg` files to `.mbox` format
- **mail-parser** — parses raw SMTP and MSG messages into a structured object

Essentially, if you need to tear apart a suspicious email file without actually opening it, REMnux is your sandbox.
