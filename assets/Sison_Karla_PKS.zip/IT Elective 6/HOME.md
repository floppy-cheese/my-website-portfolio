# IT Elective 6 — Personal Knowledge System 

This is my PKS for IT Elective 6, covering cybersecurity concepts, frameworks, and methodologies. A submission for my final project on the course.

---

## Topics

- [[Career Opportunities in IT Security]]
- [[The Adversarial Hook - Understanding Initial Access and Exploitation]]
- [[Introduction to Security Models and Threat Frameworks]]
- [[Initial Access (TA0001) — Phishing (T1566)]]
- [[Initial Access (TA0001) — Valid Accounts (T1078)]]
- [[Initial Access (TA0001) — Exploit Public-Facing Application (T1190)]]
- [[Execution (TA0002) — Command and Scripting Interpreter (T1059)]]
- [[Persistence (TA0003)]]
- [[Discovery (TA0007)]]

---

## About This Vault

Built in Obsidian. All notes are in Markdown (`.md`) format with internal links and images.
