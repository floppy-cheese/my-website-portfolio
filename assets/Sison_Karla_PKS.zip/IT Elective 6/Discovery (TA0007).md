# Discovery (TA0007)

Tags: #cybersecurity #discovery #MITRE #lateral-movement #reconnaissance
Related: [[HOME]] | [[IT Elective 6/Persistence (TA0003)|Persistence (TA0003)]]

---

## What is Discovery (TA0007)?

The adversary is trying to figure out the environment.

Discovery is the reconnaissance phase *after* the attacker is already inside. Before moving laterally or escalating privileges, they need to understand where they are, what's around them, and what's worth going after. It's the "look around before making a move" phase.

---

## Discovery Taxonomy

Discovery breaks down into three main categories, each with specific techniques:

**Identity & Access**
- T1087 — Account Discovery
- T1069 — Permission Groups
- T1201 — Password Policy

**Network & Infrastructure**
- T1046 — Network Service Discovery
- T1580 — Cloud Infrastructure
- T1482 — Domain Trust Discovery

**System State & Environment**
- T1057 — Process Discovery
- T1518 — Software Discovery
- T1673 — Virtual Machine Discovery

The pattern is clear: attackers want to know who has access, what the network looks like, and what's running on the machines.

---

## Goals of Discovery

Four things the attacker is trying to accomplish during this phase:

- **Topology Mapping** — locating internal networks, remote systems, and active services. Building a mental map of the environment.
- **Identity Harvesting** — enumerating local, domain, and cloud accounts to identify the most valuable escalation paths.
- **Target Selection** — locating high-value data repositories and domain trust relationships that can be used for lateral movement.
- **Defense Evasion** — identifying installed security software, debuggers, and sandboxes so they can alter their malicious behavior to avoid detection.

Discovery isn't just about finding targets, it's also about finding the cameras or "eyes" first.

---

## Key Techniques

### T1046 — Network Service Discovery

Scanning the internal network to find what ports and services are running, basically figuring out what's open and potentially reachable. Attackers use this to map out the network from the inside, the same way Shodan does from the outside.

### T1087 — Account Discovery

Enumerating user and admin accounts on the system or domain. Once you know what accounts exist and what groups they're in, you know where the privilege is and who to target next.

### T1622 — Debugger Evasion &
### T1497 — Sandbox Evasion

Checks to see if the malware is being analyzed. If a debugger or sandbox is detected, the malware can change its behavior — go dormant, act clean, or shut itself down — to avoid leaving any detectable trace during analysis. It's essentially the malware checking whether it's being watched.

---

## Discovery Techniques: Host & System

| ID    | Name                         | Definition                                                                                                                                |
| ----- | ---------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------- |
| T1083 | File and Directory Discovery | Systematic inspection of file systems to locate sensitive documents, configurations, backups, and credential stores                       |
| T1057 | Process Discovery            | Enumerating running processes to identify active applications and security tools, often used to select processes for injection or evasion |
| T1012 | Query Registry               | Examining Windows registry keys to locate configuration data, startup entries, or pointers to stored credentials                          |

These three cover the basics of what an attacker wants to know about any endpoint they land on. What files are there, what's running, and what does the registry reveal. Security tools show up in process lists which is why T1057 feeds directly into defense evasion decisions.

---

## Discovery Techniques: Cloud & Virtualized Environments

*(Applies to environments like AWS, Azure, etc.)*

| ID    | Name                           | Definition                                                                                                           |
| ----- | ------------------------------ | -------------------------------------------------------------------------------------------------------------------- |
| T1580 | Cloud Infrastructure Discovery | Enumerating cloud resources (instances, subnets, load balancers) to map the environment and locate misconfigurations |
| T1538 | Cloud Service Dashboard        | Accessing cloud management consoles to locate settings and controls with broad resource access                       |
| T1619 | Cloud Storage Object Discovery | Listing buckets/containers and their objects to find exposed data or backups containing sensitive secrets            |

Cloud environments introduce a whole new attack surface. Misconfigured buckets and overly permissive IAM roles are extremely common, and T1619 is basically the attacker checking if someone left a door unlocked. T1538 is particularly dangerous because management consoles often have read access to everything.

---

## Discovery Target Matrix

| Domain | Targets | Key TTPs | Primary Data Source | Evasion Profile |
|--------|---------|----------|---------------------|-----------------|
| **Endpoint** | Processes, Registries, Local Files | T1057, T1012, T1083 | API & Syscall Logging, EDR Events | Blends with local system administration |
| **Network** | Ports, Shares, Subnets | T1046, T1135, T1018 | Bro/Zeek Sensors, Netflow | Easily lost in high-volume legitimate network traffic |
| **Cloud** | IAM, Buckets, Dashboards | T1087.004, T1580, T1619 | Cloud API Logs | Indistinguishable from legitimate developer API calls without strict baselining |

The evasion profile column is the important part here. Endpoint discovery looks like sysadmin work, network scanning blends into normal traffic, and cloud enumeration looks exactly like a developer just poking around. Detection without a solid baseline is nearly impossible.

---

## Detection and Prevention

Three layers of detection, stacked by effectiveness:

- **TTP-Based Detection (The Gold Standard)** — hunts for the underlying Tactics, Techniques, and Procedures themselves, not just known artifacts. Even if the malware is new, the behavior follows the same patterns. This is the hardest to build but the most resilient.
- **Anomaly-Based Detection** — uses machine learning and statistical analysis to flag atypical events. Useful for catching things that don't match any known signature but feel off compared to the baseline.
- **Signature/IOC-Based Detection** — scans for known Indicators of Compromise like, file hashes, malicious IPs, domain names. Fast and cheap, but only works for threats that have already been seen before.

In practice you want all three — IOC-based catches known threats quickly, anomaly-based covers the unknown, and TTP-based is what actually stops a sophisticated attacker who's specifically trying to avoid the first two.
