Tags: #cybersecurity #CIA-triad #risk #MITRE #threat-frameworks
Related: [[HOME]] | [[The Adversarial Hook - Understanding Initial Access and Exploitation]] | [[Initial Access (TA0001) — Phishing (T1566)]]

---

## The Baseline: What Are We Actually Dealing With?

Before diving into frameworks and models, we first need to understand the four core things that basically define what security is trying to solve.

---

### 1. Assets — The "What"

Anything that has value to the organization that needs protecting. Pretty broad, but it breaks down into two types:

- **Tangible** — the physical stuff: servers, laptops, networking equipment, buildings
- **Intangible** — the harder-to-see stuff: customer data, intellectual property (IP), company reputation

Reputation is easy to underestimate but it's arguably the most damaging to lose.

---

### 2. Vulnerabilities — The "Weakness"

A flaw or weakness in a system's security procedures, design, implementation, or internal controls. Basically, the cracks in the armor.

- **Technical** — unpatched software, misconfigured firewalls, zero-day bugs
- **Human** — untrained employees, weak/guessable passwords

The human ones tend to be more common and honestly harder to fix.

---

### 3. Threats — The "Danger"

Any circumstance or event that has the potential to negatively impact an asset. A threat doesn't have to be malicious either.

- **Intentional** — hackers, malicious insiders, ransomware gangs
- **Accidental/Natural** — an employee accidentally deleting a database, power outages, floods

Not every threat is someone out to get you. Sometimes it's just bad luck or a clumsy coworker.

---

### 4. Risk — The "Calculation"

The probability that a threat successfully exploits a vulnerability, and what the resulting business impact would be.

> **Risk = Threat × Vulnerability × Impact**

If any one of those is zero, the risk drops. That's the whole point of patching vulnerabilities and training employees. You're reducing the multiplication.

---

## The CIA Triad

The foundational model for developing security policies and evaluating risk. Everything in security basically traces back to protecting at least one of these three things.

|                     | Goal                                   |
| ------------------- | -------------------------------------- |
| **Confidentiality** | Preventing unauthorized *disclosure*   |
| **Integrity**       | Preventing unauthorized *modification* |
| **Availability**    | Preventing *disruption* of access      |

Think of it like this: confidentiality is keeping secrets, integrity is keeping things accurate, and availability is keeping things running. A good security posture tries to maintain all three at once, though sometimes they trade off against each other.

---

## Threat Frameworks

Threat frameworks are standardized, structured methodologies for analyzing, categorizing, and mitigating cyber threats. Instead of just reacting to attacks, they give security teams a common language and structure to work with.

---

### MITRE ATT&CK Framework

ATT&CK stands for **Adversarial Tactics, Techniques, and Common Knowledge.**

It's a globally accessible knowledge base built from real-world observations of how actual attackers operate. The big shift with ATT&CK compared to something like the CIA Triad is its perspective. It stops asking *"what are we protecting?"* and starts asking *"how do attackers actually get in and move around?"*

It also maps the entire cyber kill chain from a post-compromise perspective. Meaning it focuses on what happens after an attacker already has some kind of foothold.

#### How It's Structured

- **Tactics (The "Why")** — the attacker's short-term goal at each stage, e.g., Initial Access, Privilege Escalation
- **Techniques (The "How")** — the specific method used to hit that goal, e.g., Phishing, Token Manipulation

Each tactic has multiple techniques under it, and each technique can have sub-techniques. It gets very granular.

#### What Security Teams Use It For

- **Adversary Emulation** — designing realistic penetration tests that actually mimic real attacker behavior
- **SOC Alert Mapping** — giving the Security Operations Center a standardized way to label and categorize alerts
- **Gap Analysis** — finding the blind spots in a network's defenses by checking which techniques you have no detection for
