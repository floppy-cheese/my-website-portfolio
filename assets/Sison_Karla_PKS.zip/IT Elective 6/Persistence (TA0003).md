Tags: #cybersecurity #persistence #MITRE #registry #DLL #fileless-malware #macros
Related: [[HOME]] | [[Execution (TA0002) — Command and Scripting Interpreter (T1059)]] | [[Discovery (TA0007)]]

---

## What is Persistence (TA0003)?

Persistence is about staying in. Once an attacker has access, the last thing they want is to lose it because someone rebooted the machine or changed a password. Persistence techniques ensure their code keeps running across restarts, credential changes, and other interruptions.

Without persistence, the attacker basically has to start over every time anything changes. With it, they become a permanent resident.

---

## Key Categories of Persistence

The areas adversaries typically target to stay hidden:

1. **Account Manipulation** — modifying existing accounts or creating new ones they control
2. **Boot/Logon Auto-start** — making sure their code runs every time the system starts or a user logs in
3. **Scheduled Tasks** — using built-in OS utilities to trigger execution at set times or events
4. **Hijacking Execution Flow** — redirecting legitimate software processes to run malicious payloads instead
5. **Browser/App Extensions** — hiding in "soft" targets like Chrome extensions or IDE plugins

---

## Mapping the Persistence Architecture

![[Screenshot 2026-05-02 172712.png]]

To hunt persistent threats, defenders need to think about mechanisms not by what they're called, but by when the OS is tricked into executing them. The diagram maps everything back to the two core trigger moments: System Boot & User Login.

From those two entry points, four categories branch out:

- **User-Level Trigger** → Startup Folders (T1547.001), Scheduled Tasks (T1053)
- **Configuration & Registry** → Run/RunOnce Keys (T1547.001), Winlogon Helpers (T1547.004)
- **App Execution** → Office App Startup (T1137), Execution Flow Hijacking (T1574)
- **Deep System / Kernel** → Linux Kernel Modules (T1547.006), System Firmware

The deeper the layer, the harder it is to detect and remove.

---

## T1098 — Account Manipulation

A real-world example: **Scattered Spider** (also known as 0ktapus or Muddled Libra), an active threat group operating since at least 2022.

Their technique on VMware ESXi environments: they added accounts to the ESX Admins group, giving themselves full administrative rights within vSphere. VMware ESXi is a Type-1 bare-metal hypervisor that sits directly on physical server hardware so, admin access there means control over every virtual machine running on it.

Scattered Spider has been observed leveraging ALPHV (BlackCat) ransomware as their end-stage payload.

---

## T1547 — Boot or Logon Autostart Execution

Adversaries configure system settings to automatically execute their code at boot or login — either to maintain persistence or to gain higher privileges.

**APT42** is a known group that modifies the registry to maintain persistence this way.

Common methods:
- **Registry Run Keys** — adding entries to `HKLM\Software\Microsoft\Windows\CurrentVersion\Run`
- **Startup Folder** — dropping shortcuts into the user's startup directory

---
## Registry Autorun Keys: The RunOnce Quirk

![[Screenshot 2026-05-02 172837.png]]

There are two flavors of autorun keys and they behave very differently:

**Run Key (`HKCU\...\CurrentVersion\Run`)**
User logs in → payload executes → **key stays in the registry**. Persistent across every login.

**RunOnce Key (`HKLM\...\CurrentVersion\RunOnce`)**
User logs in → key deletes itself *first* → then payload executes. The key is gone by the time you look for it.

Attackers can write a RunOnce key right before system shutdown. On next boot it executes, then vanishes, leaving no obvious registry footprint during an active logged-in session. A forensic blind spot by design.

---

## Startup Directories & Scheduled Tasks

![[Screenshot 2026-05-02 172950.png]]

**Startup Directories (T1547.001)**
The simplest persistence method there is. Drop a file in the Startup folder (`C:\Users\[User]\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup`) and it runs automatically on login. High reliability, but it's also easily spotted by anyone who knows to look there.

**Scheduled Tasks (T1053)**
More flexible and stealthier. Uses Windows Task Scheduler (`schtasks`) to create XML-defined tasks with configurable triggers. Time-based, logon-based, or event-based. The attacker specifies the trigger and the payload path, and the OS does the rest on schedule.

---

## Grafting onto the Logon Sequence — Winlogon Helpers (T1547.004)

![[Screenshot 2026-05-02 173040.png]]

Windows uses `winlogon.exe` to orchestrate the desktop session after credentials are entered. It reads registry helper paths from `HKLM\Software\...\Winlogon` to set up the user environment.

By appending a malicious path to the **Userinit** or **Shell** subkeys, malware embeds itself directly into the logon sequence. The flow becomes:

1. User enters credentials
2. `winlogon.exe` activates
3. Reads `HKLM\Software\...\Winlogon`
4. Runs `userinit.exe` (legitimate) **and** `malware.exe` (malicious appended path)
5. Desktop session starts — attacker's code is already running

It's subtle because the legitimate process still runs normally. Nothing looks broken.

---

## T1574.001 — Hijack Execution Flow: DLL

DLLs (Dynamic-Link Libraries) are shared code libraries that multiple programs use simultaneously. They're not inherently malicious but they can be abused through search order hijacking, sideloading, or phantom DLL hijacking.

---

### Intercepting the Path: Execution Flow Hijacking

![[Screenshot 2026-05-02 173250.png]]

**Normal execution:** App starts → asks OS for `library.dll` → OS searches System32 → finds the legitimate DLL → done.

**Search Order Hijacking (T1574):** App starts → asks OS for `library.dll` → OS searches the *local app directory first* → finds the attacker's fake `library.dll` → executes payload. The fake DLL can even quietly forward requests to the real one so the app still works normally and nothing seems wrong.

The OS's own search order becomes the weapon.

---

## Evading the File System: Fileless Registry Persistence

![[Screenshot 2026-05-02 173347.png]]

**File-Based Execution** — the traditional approach. A Run key in `HKCU\...\Run` points to a `payload.exe` sitting on disk. Antivirus can find it, scan it, flag it.

**Fileless Execution** — no file ever touches disk. The payload is stored as an encoded blob directly in the registry. On execution, it's read from the registry, loaded into RAM, and executed as PowerShell in memory. Nothing for a disk scanner to find.

---

## Weaponized Macros (T1137.001)

Macros are VBA or XLM scripts built to automate repetitive tasks in Office documents. Attackers weaponize this legitimate functionality so their code runs the moment a user opens a document.

**The attack sequence:**

1. **Delivery** — social engineering via email, disguised as invoices, resumes, or "protected" content
2. **Activation** — user is tricked into clicking "Enable Content" or "Enable Macros"
3. **Execution** — the macro kicks off a payload, usually calling PowerShell or Command Line to download secondary malware like Emotet or Qakbot

The whole thing relies on the user clicking that enable button. Which is why awareness training matters but also why attackers make the lure convincing enough that people do it anyway.

---

## Defending Against Persistence

Blue Team actions:

- **Auditing** — monitor registry changes, new service creations, and scheduled task modifications. If something new appeared in Run keys or the Startup folder, you want to know immediately.
- **Privilege Management (PoLP)** — follow the Principle of Least Privilege. If regular users can't write to registry Run keys or create services, a lot of these techniques become much harder to pull off.
- **File Integrity Monitoring (FIM)** — alert on changes to critical OS files — DLLs, SSH keys, configuration scripts. Anything that shouldn't change but did.
- **Application Whitelisting** — prevent unauthorized binaries or scripts from running in the first place. If only approved executables can run, dropping `malware.exe` in the Startup folder does nothing.
